from typing import Any
from tkinter import Entry, Toplevel, Button, Label
from tkinter.font import Font
from tkinter.ttk import Button, Entry, Label
import datetime

def date_formatter(e: Entry) -> str:
    try:
        cur_date = datetime.datetime.now()
        formatted_date = cur_date.strftime(e.get().strip())
    
    except ValueError:
        return 'Invalid date format'
    
    except Exception as e:
        return f'Unknown error: {e}'
    
    else:
        return formatted_date

def start(_globals: dict[str, Any]):
    new_win = Toplevel(_globals['desktop_win'])
    new_win.title('WriterClassic - Date & Time (By: MF366)')
    new_win.resizable(True, False)

    formatter = Entry(new_win, font=Font(new_win, size=12, weight='normal', slant='roman', underline=False, overstrike=False))

    preview = Label(new_win, text="", font=_globals['FontSet'])

    butt_preview = Button(new_win, text='Preview', command=lambda:
        preview.configure(text=date_formatter(formatter)))

    butt_copy = Button(new_win, text='Insert', command=lambda:
        _globals['TextWidget'].insert(_globals['INSERT'], date_formatter(formatter)))
    
    butt_close = Button(new_win, text='Done', command=new_win.destroy)

    formatter.pack()
    butt_preview.pack()
    butt_copy.pack()
    preview.pack()
    butt_close.pack()
    
    new_win.mainloop()
