from tkinter import END
import subprocess
import hashlib

def plugin(**stuff):
    """
    Wassuuuupppp!!!
    """
    # Grab file contents
    to_hash: str = stuff["TextWidget"].get(0.0, END)
    # Hash them
    output_hash = int.from_bytes(hashlib.sha1(to_hash.strip().encode("UTF-8")).digest(), "little", signed=False)
    # And write to clipboard...
    subprocess.run(['clip.exe'], input=str(output_hash).encode("UTF-8"), check=False)
    # That's all!
