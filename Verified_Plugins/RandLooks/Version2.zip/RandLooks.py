import random
from tkinter import Text

def random_light_color():
    red = random.randint(175, 255)
    green = random.randint(175, 255)
    blue = random.randint(175, 255)

    hex_color = "#{:02X}{:02X}{:02X}".format(red, green, blue)

    return hex_color

def random_dark_color():
    red = random.randint(0, 128)
    green = random.randint(0, 128)
    blue = random.randint(0, 128)

    hex_color = "#{:02X}{:02X}{:02X}".format(red, green, blue)

    return hex_color

def random_medium_color():
    red = random.randint(129, 174)
    green = random.randint(129, 174)
    blue = random.randint(129, 174)

    hex_color = "#{:02X}{:02X}{:02X}".format(red, green, blue)

    return hex_color

def random_dark_theme(text_widget: Text):    
    text_widget.configure(background=random_dark_color(), foreground=random_light_color(), insertbackground=random_light_color(), borderwidth=random.randint(4, 8))

def random_light_theme(text_widget: Text):
    text_widget.configure(background=random_light_color(), foreground=random.choice((random_dark_color(), random_medium_color())), insertbackground=random.choice((random_dark_color(), random_medium_color())), borderwidth=random.randint(4, 8))

def plugin(_vars):
    x = _vars["mb"].askyesnocancel("WriterClassic - RandLooks", "Thank you for using RandLooks. <3\nClick Yes to randomise a Dark Theme.\nNo to randomise a Light Theme.\nCancel to leave the plugin.\n\n--\nBest regards,\nMF366")
    
    if x:
        random_dark_theme(_vars["TextWidget"])
        
    elif x == False:
        random_light_theme(_vars["TextWidget"])
        
    elif x == None:
        _vars["TextWidget"].configure(borderwidth=5)
