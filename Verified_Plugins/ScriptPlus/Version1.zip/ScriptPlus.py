from typing import Any
import os
from tkinter import Toplevel, IntVar, Listbox, SINGLE, END
from tkinter.ttk import Checkbutton, Button


def make_list(_globals: dict[str, Any]) -> tuple[list[str], list[str]]:
    z: list = []
    y: list = []

    for root, _, files in os.walk(_globals['scripts_dir']):
        for filename in files:
            if filename.lower().endswith('.wscript'):
                filepath = os.path.join(root, filename)
                z.append(filepath)
                y.append(os.path.basename(filepath)[:-8])
        
    return z[:], y[:]


def run_script(*params):
    globs: dict[str, Any] = params[0]
    selection: Listbox = params[1]
    checkbutt: IntVar = params[2]
    t1: list[str] = params[3]
    t2: list[str] = params[4]
    file_path: str | None = None
    
    try:
        selected = selection.get(selection.curselection())

        write_perms = 'write' if checkbutt.get() else 'read'

        file_path = t1[t2.index(selected)]

        script = globs['WScript']()
        script.loadpath(file_path)

        script.run(scope=write_perms)

    except IndexError:
        # [!?] No items are selected.
        globs['mb'].showwarning("ScriptPlus", "Please select a script to run.")
        
    except ValueError as ve:
        # [!?] Specific errors raised by WScript.loadpath
        globs['mb'].showerror("ScriptPlus", f"Invalid script path: {ve}")    

    except Exception as e:
        # [!] It didn't work (General Exception)
        globs['mb'].showerror("ScriptPlus", f'Error at script located at {file_path}\n{e}')
    
    else:
        # [*] It worked!
        globs['mb'].showinfo("ScriptPlus", f'Script at {file_path} executed successfully.')


def start(_globals: dict[str, Any]):
    w: Toplevel = Toplevel(_globals['desktop_win'])
    w.resizable(False, False)
    
    v: IntVar = IntVar(w, 0)
    
    c: Checkbutton = Checkbutton(w, text="Use 'write' permissions for globals", variable=v)
    
    o: Listbox = Listbox(w, selectmode=SINGLE, highlightbackground='white', highlightcolor='black', background='black', foreground='white', borderwidth=3)
    
    t1, t2 = make_list(_globals)
    
    for i in t2:
        o.insert(END, i)
    
    b: Button = Button(w, text='Run', command=lambda:
        run_script(_globals, o, v, t1, t2))
    
    o.pack()
    c.pack()
    b.pack()
    
    w.mainloop()
