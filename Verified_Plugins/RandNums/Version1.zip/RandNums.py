import random

def start(_vars):
    x: str = _vars["sdg"].askstring("WriterClassic - RandNums", "Define the boundaries and properties for the random number like this:\nx,y,a\n--\nx - minimum number\ny - maximum number\na - 1 if decimals allowed, 0 if only integers", initialvalue="1,6,0")
    
    x = x.split(",")
    
    y: int | float = random.randint(x[0], x[1])
    
    if int(x[2]) == True:
        y += random.random()
    
    _vars["mb"].showinfo("WriterClassic - RandNums", f"Your number is...\n{y}")
