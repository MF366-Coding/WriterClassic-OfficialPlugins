from typing import Any, Callable
from tkinter import Label, Toplevel, Button
from tkinter.font import Font
from tkinter.ttk import Label, Button
from tkinter.simpledialog import askstring
import tkinter.messagebox as mb
import os, sys, requests

_globals: dict[str, Any | Callable]

def plug_actions(action_id: int, variable_passed: list | tuple | Toplevel | None = None) -> Any:
    # [*] Increase Zoom Level
    if action_id == 1:
        if variable_passed[1] > 250:
            return
        
        variable_passed[1] += 2
        _globals["TextWidget"].configure(font=(_globals["FontSet"].cget('family'), variable_passed[1]))
        return
    
    # [*] Decrease Zoom Level 
    if action_id == 2:
        if variable_passed[1] < 5:
            return
        
        variable_passed[1] -= 2
        _globals["TextWidget"].configure(font=(_globals["FontSet"].cget('family'), variable_passed[1]))
        return
    
    # [*] Restore Zoom Level
    if action_id == 3:
        variable_passed[1] = variable_passed[0]
        _globals["TextWidget"].configure(font=(_globals["FontSet"].cget('family'), variable_passed[0]))
        return
    
    # [*] Restart App
    if action_id == 4:
        y = os.path.exists(os.path.join(_globals["script_dir"], "WriterClassic.exe"))
        
        if y and sys.platform == "win32":
            x = os.path.join(_globals["script_dir"], "WriterClassic.exe")
            
        elif not y and sys.platform == "win32":
            x = "python " + _globals["script_path"]
            
        else:
            x = "python3 " + _globals["script_path"]
            
        _globals["desktop_win"].destroy()
        os.system(x)
        
        return
    
    # [*] Quit the app
    if action_id == 5:
        _globals["desktop_win"].destroy()
        sys.exit()
    
    # [*] Check a Language Index
    if action_id == 6:
        x = _globals["sdg"].askinteger("WriterClassic - ExtraTools", "Please insert the index of the expression you want to check.", initialvalue=1, minvalue=1, maxvalue=len(_globals["lang"]) - 1)
        
        if x != None:
            _globals["mb"].showinfo("WriterClassic - ExtraTools", _globals["lang"][x])
        
        return
    
    # [*] Clear the log file
    if action_id == 7:
        _globals["clear_log_file"]()
        
        return
    
    # [*] Remove the 'temp' folder
    if action_id == 8:
        _globals["remove_action"](9)
        
        return
    
    # [*] Save WriterClassic settings
    if action_id == 9:
        _globals["fast_dump"]()
        
        return

    # [i] New in Version 2
    # [*] Raw Contents of a website
    if action_id == 10:
        a = askstring('WriterClassic - ExtraTools', 'Please enter a valid link.')
        
        try:
            response = requests.get(a, timeout=3, allow_redirects=False)
            
            if response.status_code != 200:
                mb.showwarning('WriterClassic - Website might be down', f'Status code of website is not 200 (a.k.a. Sucessful connection): {response.status_code}')
                return
            
            raw_contents = response.text
            
            b = mb.askyesno('WriterClassic - ExtraTools', 'This operation will overwrite the contents of the editor. Run anyway?')
            
            if not b:
                return
            
            _globals['TextWidget'].replace(0.0, _globals['END'], raw_contents)
            
        except Exception as e:
            mb.showerror('WriterClassic - ExtraTools', f"An error occured: {e}")
        
        else:
            response.close()
        
        return
        
    # [*] Extra $VARS
    if action_id == 11:
        c = askstring('WriterClassic - Extra$VARS', 'Please enter a name for the variable.', initialvalue='SOMEVAR').strip().replace(' ', '_').upper()
        d = c
        
        if not isinstance(d, str) or d == '':
            mb.showerror('WriterClassic - Extra$VARS', 'Invalid variable name.')
            return
        
        if not c.startswith('$'):
            d = f"${c}"
        
        e = askstring('WriterClassic - Extra$VARS', 'Enter a respective value for it.\nThis could be a system variable or an hardcoded value.\nVariables aren\'t saved so next time you open WriterCLassic you won\'t have the ones you defined with ExtraTools.', initialvalue='Insert value').strip()
        
        if not isinstance(e, str) or e == '':
            mb.showerror('WriterClassic - Extra$VARS', 'Invalid variable value.')
            return
        
        _globals['WCLASSIC_VARS'][d] = e
        return        

def make_ui():
    # [*] Setting up some variables
    FontSet: Font = _globals['FontSet']
    
    font_size: list[int] = [FontSet.cget('size'), FontSet.cget('size')]
    
    # [*] Create a new window
    new_win: Toplevel = Toplevel(_globals["desktop_win"])
    new_win.title("WriterClassic - ExtraTools")
    new_win.resizable(False, False)
    
    c: str | None | Any = os.path.join(_globals["data_dir"], "app_icon.ico")
    
    if sys.platform == "win32" and os.path.exists(c):
        new_win.iconbitmap(c)
    
    label_1 = Label(new_win, text="Zoom", font=("Arial", 15), justify="center")
    label_2 = Label(new_win, text="Other Options", font=("Arial", 15), justify="center")
    
    butt_1 = Button(new_win, text="Increase (+)", command=lambda:
        plug_actions(1, font_size))    
    
    butt_2 = Button(new_win, text="Restore (0)", command=lambda:
        plug_actions(3, font_size))
    
    butt_3 = Button(new_win, text="Decrease (-)", command=lambda:
        plug_actions(2, font_size))
    
    butt_4 = Button(new_win, text="Restart WriterClassic", command=lambda:
        plug_actions(4))
    
    butt_5 = Button(new_win, text="Dump WriterClassic settings", command=lambda:
        plug_actions(9))
    
    butt_6 = Button(new_win, text="Remove the temp dir", command=lambda:
        plug_actions(8))
    
    butt_7 = Button(new_win, text="Clear the Log File", command=lambda:
        plug_actions(7))
    
    butt_8 = Button(new_win, text="Check a Languge Index", command=lambda:
        plug_actions(6))
    
    butt_9 = Button(new_win, text="Close WriterClassic (No Confirmation)", command=lambda:
        plug_actions(5))
    
    butt_10 = Button(new_win, text="RAW Editor", command=lambda:
        plug_actions(10))
    
    butt_11 = Button(new_win, text="Extra$VARS", command=lambda:
        plug_actions(11))
    
    # [*] Placing the widgets in the window
    label_1.grid(column=0, row=0)
    label_2.grid(column=1, row=0)
    
    butt_1.grid(column=0, row=1)
    butt_2.grid(column=0, row=2)
    butt_3.grid(column=0, row=3)
    
    butt_7.grid(column=1, row=1)
    butt_8.grid(column=1, row=2)
    butt_5.grid(column=1, row=3)
    butt_6.grid(column=1, row=4)
    butt_10.grid(column=1, row=5)
    butt_11.grid(column=1, row=6)
    butt_4.grid(column=1, row=7)
    butt_9.grid(column=1, row=8)
    
    # [*] Setting up key bindings for the zoom feature  
    new_win.bind("+", lambda a:
        plug_actions(1, font_size))
    
    new_win.bind("0", lambda a:
        plug_actions(3, font_size))
    
    new_win.bind("-", lambda a:
        plug_actions(2, font_size))
    
    # [i] And done!

def start(_vars: dict[str, Any | Callable]):
    global _globals
    
    _globals = _vars
    
    make_ui()
    