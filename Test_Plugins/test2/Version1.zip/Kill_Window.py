def plugin(**kargs):
    kargs["desktop_win"].destroy()